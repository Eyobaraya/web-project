<?php
require_once 'includes/db.php';

$user_id = isset($_GET['user']) ? (int) $_GET['user'] : 0;

/* ── Fetch the user ─────────────────────────────────────────────── */
$stmt = $conn->prepare('SELECT id, name FROM users WHERE id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    http_response_code(404);
    die('User not found');
}

$page_title = $user['name'] . ' – Portfolio';
require_once 'includes/header.php';

/* ── Fetch the user’s projects ──────────────────────────────────── */
$stmt = $conn->prepare(
    'SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC'
);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$res = $stmt->get_result();

/* ── Output ─────────────────────────────────────────────────────── */
echo '<h2>' . htmlspecialchars($user['name']) . ' – Projects</h2>';

if ($res && $res->num_rows > 0) {
    echo '<section class="grid">';
    while ($row = $res->fetch_assoc()) {
        $row['author'] = $user['name'];          // add author name
        $project = (object) $row;                // convert array → object
        include 'templates/project_card.php';    // uses $project
    }
    echo '</section>';
} else {
    echo '<p>No projects yet.</p>';
}

require_once 'includes/footer.php';
?>