<?php
require_once 'includes/auth.php';
$message = '';

// Create uploads directory if it doesn't exist
if (!file_exists('uploads')) {
    mkdir('uploads', 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $desc  = trim($_POST['description']);
    $type  = $_POST['project_type']; // 'image' or 'web'

    if (isset($_FILES['project_file']) && $_FILES['project_file']['error'] === 0) {
        $filename = $_FILES['project_file']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        // Validate based on project type
        if ($type === 'image') {
            $allowed = ['jpg','jpeg','png','gif'];
            $filetype = 'image';
        } else { // web project
            $allowed = ['zip','html','htm','css','js'];
            $filetype = 'web';
        }

        if (in_array($ext, $allowed)) {
            // Create type-specific subfolder (images/ or web/)
            $subfolder = 'uploads/' . $filetype . '/';
            if (!file_exists($subfolder)) {
                mkdir($subfolder, 0755, true);
            }
            
            $new_filename = uniqid() . '.' . $ext;
            $target = $subfolder . $new_filename;

            if (move_uploaded_file($_FILES['project_file']['tmp_name'], $target)) {
                // Save to database
                $stmt = $conn->prepare('INSERT INTO projects(title,description,file_path,user_id,type,created_at) 
                                      VALUES(?,?,?,?,?,NOW())');
                $stmt->bind_param('sssis', $title, $desc, $target, $_SESSION['user_id'], $filetype);
                
                if ($stmt->execute()) {
                    header('Location: index.php');
                    exit;
                } else {
                    $message = 'Database error: ' . $conn->error;
                }
            } else {
                $message = 'Failed to move file. Check folder permissions.';
            }
        } else {
            $message = "Unsupported file type for $type project. Allowed: " . implode(', ', $allowed);
        }
    } else {
        $message = 'Please select a file or check upload errors';
    }
}

$page_title = 'Upload Project';
require_once 'includes/header.php';
?>

<h2>Upload Project</h2>
<?php if ($message) echo "<p class='error'>$message</p>"; ?>

<form method="post" enctype="multipart/form-data">
  <label>Project Type:
    <select name="project_type" required>
      <option value="image">Image Project</option>
      <option value="web">Web Project (HTML/ZIP)</option>
    </select>
  </label><br>
  
  <label>Title: <input type="text" name="title" required></label><br>
  
  <label>Description: <textarea name="description" required></textarea></label><br>
  
  <label>Project File: 
    <input type="file" name="project_file" required
           accept="image/*,.zip,.html,.htm,.css,.js">
  </label><br>
  
  <button type="submit">Upload</button>
</form>

<?php 
require_once 'includes/footer.php';
?>