<?php
require_once 'includes/auth.php'; // ensures login
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
// Fetch project
$stmt = $conn->prepare('SELECT * FROM projects WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();
if (!$project) {
    die('Project not found');
}
if (!can_edit_project($project['user_id'])) {
    http_response_code(403);
    die('Forbidden');
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $desc  = trim($_POST['description']);

    // Handle optional image replacement
    $image_sql = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $ext      = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $allowed  = ['jpg','jpeg','png','gif'];
        if (in_array(strtolower($ext), $allowed)) {
            $filename = uniqid() . '.' . $ext;
            $target   = 'uploads/' . $filename;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                // delete old
                if (file_exists('uploads/' . $project['image'])) unlink('uploads/' . $project['image']);
                $image_sql = ', image = ?';
            } else {
                $message = 'Failed to upload new image';
            }
        } else {
            $message = 'Unsupported file type';
        }
    }

    if ($message === '') {
        if ($image_sql) {
            $stmt = $conn->prepare('UPDATE projects SET title=?, description=?' . $image_sql . ' WHERE id=?');
            $stmt->bind_param('sssi', $title, $desc, $filename, $id);
        } else {
            $stmt = $conn->prepare('UPDATE projects SET title=?, description=? WHERE id=?');
            $stmt->bind_param('ssi', $title, $desc, $id);
        }
        if ($stmt->execute()) {
            header('Location: project.php?id=' . $id);
            exit;
        } else {
            $message = 'Update failed';
        }
    }
}

$page_title = 'Edit Project';
require_once 'includes/header.php';
?>
<h2>Edit Project</h2>
<?php if ($message) echo "<p class='error'>$message</p>"; ?>
<form method="post" enctype="multipart/form-data">
  <label>Title <input type="text" name="title" value="<?= htmlspecialchars($project['title']) ?>" required></label><br>
  <label>Description <textarea name="description" required><?= htmlspecialchars($project['description']) ?></textarea></label><br>
  <label>Replace Image <input type="file" name="image" accept="image/*"></label><br>
  <button type="submit">Save Changes</button>
</form>
<?php require_once 'includes/footer.php'; ?>
