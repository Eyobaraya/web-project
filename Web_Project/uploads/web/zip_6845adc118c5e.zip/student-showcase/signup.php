<?php
require_once 'includes/db.php';
if (is_logged_in()) {
    header('Location: index.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm'];

    if ($password !== $confirm) {
        $error = 'Passwords do not match';
    } else {
        $stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error = 'Email already registered';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $role = in_array($_POST['role'], ['student','employer']) ? $_POST['role'] : 'student';
            $stmt = $conn->prepare('INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)');
            $stmt->bind_param('ssss', $name, $email, $hash, $role);
            if ($stmt->execute()) {
                header('Location: login.php');
                exit;
            } else {
                $error = 'Registration failed';
            }
        }
    }
}
$page_title = 'Sign Up';
require_once 'includes/header.php';
?>
<h2>Sign Up</h2>
<?php if ($error) echo "<p class='error'>$error</p>"; ?>
<form method="post" action="">
  <label>Name <input type="text" name="name" required></label><br>
  <label>Email <input type="email" name="email" required></label><br>
  <label>Password <input type="password" name="password" required></label><br>
  <label>Role
  <select name="role" required>
    <option value="student">Student</option>
    <option value="employer">Employer</option>
  </select>
</label><br>

<label>Confirm Password <input type="password" name="confirm" required></label><br>
  <button type="submit">Sign Up</button>
</form>
<?php require_once 'includes/footer.php'; ?>
