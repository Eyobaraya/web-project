</main>
<footer>
  <p>&copy; <?= date('Y') ?> Student Showcase</p>
</footer>
<script src="/student-showcase/assets/js/scripts.js"></script>
</body>
</html>
