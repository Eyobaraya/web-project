<?php
session_start();
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'student_showcase';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die('Database error: ' . $conn->connect_error);
}

// ------ helper functions ------
function is_logged_in() {
    return isset($_SESSION['user_id']);
}
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}
function can_edit_project($owner_id) {
    return is_admin() || (is_logged_in() && $_SESSION['user_id'] == $owner_id);
}
?>
