<?php
require_once 'includes/db.php';
require_once 'includes/classes/Project.php';
require_once 'includes/header.php';

// Handle search
$searchQuery = $_GET['q'] ?? null;
if ($searchQuery) {
    $projects = Project::search($conn, $searchQuery);
} else {
    $projects = Project::fetchAllWithAuthor($conn);
}
?>

<!-- Search Bar -->
<form class="middle" method="GET" action="index.php" style="margin:auto;">
    <input type="text" name="q" placeholder="Search projects..." value="<?= htmlspecialchars($searchQuery) ?>" />
    <button type="submit">Search</button>
</form>

<?php
if (count($projects) > 0) {
    echo '<section class="grid">';
    foreach ($projects as $project) {
        include 'templates/project_card.php';
    }
    echo '</section>';
} else {
    echo '<p>No projects found.</p>';
}

require_once 'includes/footer.php';
?>
