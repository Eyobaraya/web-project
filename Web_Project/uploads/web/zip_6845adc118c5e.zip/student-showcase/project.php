<?php
require_once 'includes/db.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $conn->prepare('SELECT p.*, u.name AS author, u.email AS author_email FROM projects p JOIN users u ON p.user_id = u.id WHERE p.id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
if (!$result || $result->num_rows === 0) {
    http_response_code(404);
    die('Project not found');
}
$row = $result->fetch_assoc();
$page_title = $row['title'];
require_once 'includes/header.php';
?>
<article class="project-detail">
  <h2><?= htmlspecialchars($row['title']) ?></h2>
  <p class="byline">
    by <a href="profile.php?user=<?= $row['user_id'] ?>"><?= htmlspecialchars($row['author']) ?></a>
    – <?= date('F j, Y', strtotime($row['created_at'])) ?>
  </p>
  <img class="full" src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
  <p><?= nl2br(htmlspecialchars($row['description'])) ?></p>

  <p>
    <a class="btn" href="mailto:<?= htmlspecialchars($row['author_email']) ?>?subject=I%20saw%20your%20project%20on%20Student%20Showcase&body=Hi%20<?= urlencode($row['author']) ?>,">Contact Student</a>
    <?php if (can_edit_project($row['user_id'])): ?>
       | <a href="edit_project.php?id=<?= $row['id'] ?>">Edit</a>
       | <a href="delete_project.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this project?');">Delete</a>
    <?php endif; ?>
  </p>
</article>
<?php require_once 'includes/footer.php'; ?>
