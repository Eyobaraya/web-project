<?php
require_once 'includes/db.php';
if (is_logged_in()) {
    header('Location: index.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare('SELECT id, password, name, role FROM users WHERE email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $hash, $name, $role);
        $stmt->fetch();
        if (password_verify($password, $hash)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['user_name'] = $name;
            $_SESSION['role'] = $role;
            header('Location: index.php');
            exit;
        }
    }
    $error = 'Invalid credentials';
}
$page_title = 'Login';
require_once 'includes/header.php';
?>
<h2>Login</h2>
<?php if ($error) echo "<p class='error'>$error</p>"; ?>
<form method="post" action="">
  <label>Email <input type="email" name="email" required></label><br>
  <label>Password <input type="password" name="password" required></label><br>
  <button type="submit">Login</button>
</form>
<?php require_once 'includes/footer.php'; ?>
