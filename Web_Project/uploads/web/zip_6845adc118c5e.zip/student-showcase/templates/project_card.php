<?php

if (!isset($project)) {
    // Fail-safe: do nothing if $project is missing.
    return;
}
?>
<article class="project-card">
  <a href="project.php?id=<?= htmlspecialchars($project->id) ?>">
    <img
      src="uploads/<?= htmlspecialchars($project->image) ?>"
      alt="<?= htmlspecialchars($project->title) ?>"
      class="project-image"
    >
    <h3 class="project-title"><?= htmlspecialchars($project->title) ?></h3>
  </a>

  <p class="byline">
    by&nbsp;
    <a href="profile.php?user=<?= htmlspecialchars($project->user_id) ?>"
       class="project-author">
      <?= htmlspecialchars($project->author) ?>
    </a>
  </p>
</article>
