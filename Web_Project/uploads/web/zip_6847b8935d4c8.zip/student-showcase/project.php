<?php
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    $page_title = 'Guest Profile';
    require_once 'includes/header.php';
    echo '<div class="main-content">';
    echo '<h2>You are not logged in. Viewing as Guest.</h2>';
    echo '</div>';
    require_once 'includes/footer.php';
    exit;
}

$user_id = isset($_GET['user']) ? (int) $_GET['user'] : $_SESSION['user_id'];

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT p.*, u.name AS author 
                        FROM projects p 
                        JOIN users u ON p.user_id = u.id 
                        WHERE p.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('Project not found.');
}

$project = $result->fetch_object();
$page_title = htmlspecialchars($project->title);
require_once 'includes/header.php';
?>

<div class="form-container">
  <h2><?= htmlspecialchars($project->title) ?></h2>

  <p><strong>Author:</strong> 
    <a href="profile.php?user=<?= htmlspecialchars($project->user_id) ?>">
      <?= htmlspecialchars($project->author) ?>
    </a>
  </p>

  <p><strong>Uploaded on:</strong> <?= date('F j, Y', strtotime($project->created_at)) ?></p>

  <?php if (!empty($project->image) && file_exists($project->image)): ?>
    <div style="margin: 20px 0;">
      <img src="<?= htmlspecialchars($project->image) ?>" 
           alt="Screenshot of <?= htmlspecialchars($project->title) ?>" 
           style="max-width: 100%; border: 1px solid #ccc;">
    </div>
  <?php endif; ?>

  <p><strong>Description:</strong></p>
  <p><?= nl2br(htmlspecialchars($project->description)) ?></p>

  <?php if (is_logged_in() && file_exists($project->file_path)): ?>
    <p>
      <a href="<?= htmlspecialchars($project->file_path) ?>" 
         download 
         class="btn"
         style="padding: 8px 16px; display: inline-block; background-color: #007BFF; color: white; text-decoration: none; border-radius: 5px;">
        Download Project
      </a>
    </p>
  <?php elseif (!is_logged_in()): ?>
    <p><em><a href="login.php">Log in</a> to download this project.</em></p>
  <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
