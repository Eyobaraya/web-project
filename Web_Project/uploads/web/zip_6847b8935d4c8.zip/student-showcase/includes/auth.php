<?php
require_once 'db.php';
if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}
?>
