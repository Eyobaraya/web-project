<?php if (!isset($page_title)) $page_title = 'PortfolioLink'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($page_title) ?></title>
  <link rel="stylesheet" href="/student-showcase/assets/css/style.css">
</head>
<body>
<!-- Fixed Navigation -->
<header>
  <div class="header-container">
    <h1><a href="/student-showcase/">PortfolioLink</a></h1>
    <nav>
      <a href="/student-showcase/">Home</a>
      <?php if (is_logged_in()): ?>
        <a href="/student-showcase/upload.php">Upload</a>
        <a href="/student-showcase/profile.php?user=<?= htmlspecialchars($_SESSION['user_id']) ?>">Profile</a>
        <?php if (is_admin()): ?>
          <span class="badge">Admin</span>
        <?php endif; ?>
        <a href="/student-showcase/logout.php">Logout</a>
      <?php else: ?>
        <a href="/student-showcase/login.php">Login</a>
        <a href="/student-showcase/signup.php">Sign Up</a>
      <?php endif; ?>
    </nav>
  </div>
</header>

<main>