# Student Project Showcase (Role‑Based)

Added basic **role-based permissions** so that:
1. Students can edit/delete **only** their own projects.
2. Admin users (`role='admin'`) can edit/delete **any** project.
3. Visitors/employers cannot modify projects but can click **Contact Student** to open their mail client.

## Admin Account

After importing `sql/schema.sql`, set a user to admin:

```sql
UPDATE users SET role='admin' WHERE id = 1;
```

## New Pages

* `edit_project.php?id=123`
* `delete_project.php?id=123`

Both pages check `can_edit_project()` before allowing changes.

## Schema Changes

Added `role` column to `users`.

## Contact Button

On `project.php`, a **Contact Student** button opens a `mailto:` link with the student's email address.


## Employer Role

A new user role `employer` is available.

- Employers can **log in**, **browse**, and **contact students**.
- They **cannot upload, edit, or delete** projects.
- They can be selected during sign-up.

## Signup Page Updated

The sign-up form now allows selecting your role (Student or Employer).


## Class-Based Structure

This version includes **PHP classes** for basic app structure, aligned with your course materials.

Example classes:
- `User` – handles user information and roles
- `Auth` – login/logout and session management
- `Project` – uploading and displaying projects

These classes are defined in a new folder `/includes/classes/`. No advanced OOP is used beyond what was taught in class.

## Sample Users

After importing `sql/schema.sql`, run the following to insert sample users:

```sql
INSERT INTO users (name, email, password, role) VALUES
('Alice Admin', 'admin@example.com', 'admin123', 'admin'),
('Eve Employer', 'eve@example.com', 'eve123', 'employer'),
('Sam Student', 'sam@example.com', 'sam123', 'student');
```
