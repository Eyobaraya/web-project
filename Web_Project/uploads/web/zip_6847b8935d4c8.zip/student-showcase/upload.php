<?php
require_once 'includes/auth.php';
$message = '';

if (!file_exists('uploads/web')) mkdir('uploads/web', 0755, true);
if (!file_exists('uploads/image')) mkdir('uploads/image', 0755, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $desc  = trim($_POST['description']);
    $zipPath = '';
    $screenshotPaths = [];

    // --- Handle ZIP/Web File ---
    if (isset($_FILES['project_zip']) && $_FILES['project_zip']['error'] === 0) {
        $filename = $_FILES['project_zip']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $allowed = ['zip', 'html', 'htm', 'css', 'js'];

        if (in_array($ext, $allowed)) {
            $new_filename = uniqid('zip_') . '.' . $ext;
            $zipPath = 'uploads/web/' . $new_filename;
            move_uploaded_file($_FILES['project_zip']['tmp_name'], $zipPath);
        } else {
            $message = 'Invalid ZIP/web file type.';
        }
    } else {
        $message = 'Project ZIP file is required.';
    }

    // --- Handle Screenshots ---
    if (isset($_FILES['screenshots'])) {
        foreach ($_FILES['screenshots']['tmp_name'] as $i => $tmpName) {
            if ($_FILES['screenshots']['error'][$i] === 0) {
                $imgName = $_FILES['screenshots']['name'][$i];
                $imgExt = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));
                if (in_array($imgExt, ['jpg', 'jpeg', 'png', 'gif'])) {
                    $new_img = uniqid('img_') . '.' . $imgExt;
                    $imgPath = 'uploads/image/' . $new_img;
                    move_uploaded_file($tmpName, $imgPath);
                    $screenshotPaths[] = $imgPath;
                }
            }
        }
    }

    if (empty($screenshotPaths)) {
        $message = 'At least one screenshot is required.';
    }

    // --- Save to DB ---
    if (empty($message)) {
        $screenshotsJson = json_encode($screenshotPaths);
        $stmt = $conn->prepare('INSERT INTO projects (title, description, file_path, screenshots, user_id, type, created_at) 
                                VALUES (?, ?, ?, ?, ?, "web", NOW())');
        $stmt->bind_param('ssssi', $title, $desc, $zipPath, $screenshotsJson, $_SESSION['user_id']);

        if ($stmt->execute()) {
            header('Location: index.php');
            exit;
        } else {
            $message = 'Database error: ' . $conn->error;
        }
    }
}

$page_title = 'Upload Project';
require_once 'includes/header.php';
?>

<div class="form-container">
  <h2>Upload Project</h2>
  <?php if ($message): ?>
    <p class="error"><?= htmlspecialchars($message) ?></p>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <label>Title:</label>
    <input type="text" name="title" required>

    <label>Description:</label>
    <textarea name="description" required></textarea>

    <label>Project ZIP File:</label>
    <input type="file" name="project_zip" accept=".zip,.html,.htm,.css,.js" required>

    <label>Screenshots (1–3 images):</label>
    <input type="file" name="screenshots[]" accept="image/*" multiple required>

    <button type="submit">Upload</button>
  </form>
</div>

<?php require_once 'includes/footer.php'; ?>
