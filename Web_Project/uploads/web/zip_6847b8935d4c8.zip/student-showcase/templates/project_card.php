<?php
if (!isset($project)) {
    return;
}

$screenshots = [];
if (!empty($project->screenshots)) {
    $decoded = json_decode($project->screenshots, true);
    if (is_array($decoded)) {
        $screenshots = $decoded;
    }
}
?>

<article class="project-card">
  <a href="project.php?id=<?= htmlspecialchars($project->id) ?>">
    <?php if (!empty($screenshots) && file_exists($screenshots[0])): ?>
      <img
        src="<?= htmlspecialchars($screenshots[0]) ?>"
        alt="<?= htmlspecialchars($project->title) ?>"
        class="project-image"
        style="width: 100%; border-radius: 8px; margin-bottom: 10px;"
      >
    <?php else: ?>
      <div style="width: 100%; height: 200px; background: #eee; display: flex; align-items: center; justify-content: center; color: #999;">
        No image available
      </div>
    <?php endif; ?>

    <h3 class="project-title"><?= htmlspecialchars($project->title) ?></h3>
  </a>

  <?php if (!empty($project->description)): ?>
    <p class="project-description"><?= nl2br(htmlspecialchars($project->description)) ?></p>
  <?php endif; ?>

  <p class="byline">
    by&nbsp;
    <a href="profile.php?user=<?= htmlspecialchars($project->user_id) ?>"
       class="project-author">
      <?= htmlspecialchars($project->author) ?>
    </a>
  </p>
</article>
