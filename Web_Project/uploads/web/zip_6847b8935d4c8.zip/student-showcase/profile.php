<?php
require_once 'includes/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$user_id = 0;
$user = null;

// Determine which user profile to show
if (isset($_GET['user'])) {
    $user_id = (int) $_GET['user'];
} elseif (isset($_SESSION['user_id'])) {
    $user_id = (int) $_SESSION['user_id']; // default to logged-in user
} else {
    // Not logged in and no user specified
    $page_title = 'Guest – Portfolio';
    require_once 'includes/header.php';
    echo '<div class="profile-page">';
    echo '<h2>Guest</h2><p>You are not logged in. Please <a href="login.php">log in</a> to view your profile.</p>';
    echo '</div>';
    require_once 'includes/footer.php';
    exit;
}

// Fetch the user
$stmt = $conn->prepare('SELECT id, name FROM users WHERE id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    http_response_code(404);
    $page_title = 'User Not Found';
    require_once 'includes/header.php';
    echo '<div class="profile-page">';
    echo '<h2>User not found</h2><p>The profile you’re trying to view does not exist.</p>';
    echo '</div>';
    require_once 'includes/footer.php';
    exit;
}

$page_title = $user['name'] . ' – Portfolio';
require_once 'includes/header.php';
?>

<div class="profile-page">
    <h2><?= htmlspecialchars($user['name']) ?> – Projects</h2>

    <?php
    // Fetch the user's projects
    $stmt = $conn->prepare(
        'SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC'
    );
    $stmt->bind_param('i', $user['id']);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res && $res->num_rows > 0) {
        echo '<section class="grid">';
        while ($row = $res->fetch_assoc()) {
            $row['author'] = $user['name'];
            $project = (object) $row;
            include 'templates/project_card.php';
        }
        echo '</section>';
    } else {
        echo '<p>No projects yet.</p>';
    }
    ?>
</div>

<?php require_once 'includes/footer.php'; ?>
